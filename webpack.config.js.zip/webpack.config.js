var HtmlWebpackPlugin = require('html-webpack-plugin');
var ExtractTextPlugin = require("extract-text-webpack-plugin");

module.exports = {
	entry: './src/app.js',
	output: {
		path: '/Users/eu-team/eu-work/self-practice/08_webpack101/dist',
		filename: 'app.bundle.js'
	},
	module: {
		rules: [
			{
				test: /\.sass$/, 
				use: ExtractTextPlugin.extract([
					'style-loader',
					'css-loader',
					'sass-loader'
				])
			}
		]
	},
	plugins: [
		new HtmlWebpackPlugin({
		  title: 'Project Demo',
		  minify: {
		  	collapseWhitespace: true
		  },
		  hash: true,
		  template: './src/index.html'
		}),
		new ExtractTextPlugin({
			filename: 'app.css',
			disable: false,
			allChunks: true
		})
	]
}